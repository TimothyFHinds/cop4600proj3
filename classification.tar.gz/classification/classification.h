#ifndef CLASSIFICATION
#define CLASSIFICATION

int set_classification(const char *filename, int new_class);
int get_classification(const char *filename);

#endif
